package watcharaphans.bitcombine.co.th.bitcamera.utility;

public class MyConstant {

    private String hostString = "192.168.2.199";
    private String userString = "root";
    private String passwdString = "admin123";
    private int portAnInt = 21;

//    getter คือ method ที่โยนค่าต่างให้ที่อื่น

    public String getHostString() {
        return hostString;
    }

    public String getUserString() {
        return userString;
    }

    public String getPasswdString() {
        return passwdString;
    }

    public int getPortAnInt() {
        return portAnInt;
    }


}

